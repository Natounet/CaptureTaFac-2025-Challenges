import random as r


def key():
    hexa="0123456789abcdef"
    key="".join([hexa[r.randint(0,15)] for i in range(32)])
    return key
