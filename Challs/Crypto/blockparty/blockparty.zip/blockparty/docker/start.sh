#!/bin/bash
while true; do
    python3 /app/main.py
done
