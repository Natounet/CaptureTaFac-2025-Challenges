from  Crypto.Cipher import AES
import Crypto.Util.Padding as pad
import json
import key
import socket
import threading

FLAG="fakeflag"



def crypt(text, key):
    cipher = AES.new(bytes(key,"utf-8"), AES.MODE_ECB)
    result = cipher.encrypt(text)
    result = result.hex()
    return result


def decrypt(text, key):
    text = bytes.fromhex(text)
    cipher = AES.new(bytes(key,"utf-8"), AES.MODE_ECB)
    result = cipher.decrypt(text)
    return result


def login(k):
    conn.sendall(b"Please enter your encrypted credentials:  ")
    encrypted = conn.recv(1024).decode('utf-8')
    encrypted = encrypted.strip()
    try:
        decrypted = decrypt(encrypted, k)
        decrypted = decrypt(encrypted, k)
        decrypted = pad.unpad(decrypted, 16)
        decrypted = json.loads(decrypted)
        username = decrypted["username"]
        perms = decrypted["perms"]
        if(username=="admin" and perms == "true"):
            conn.sendall(b"Welcome admin!")
            conn.sendall(b"Here is your flag: "+ FLAG.encode("utf-8") + b"\n\n")
        else:
            conn.sendall(b"Welcome "+username.encode("utf-8")+b" !\n")
            conn.sendall(b"You do not have permission to view the flag.\n\n")
    except Exception as e:
        conn.sendall(b"Your credentials are invalid be careful about the format and padding\n\n")
    return


def register(k):
    conn.sendall(b"Please enter your username:  ")
    username = conn.recv(1024).decode('utf-8')
    username = username[:-1]
    data_to_encrypt = '{"username": "' + username+ '","perms": "guest"}'
    padded_data = pad.pad(bytes(data_to_encrypt,"utf-8"), 16)
    encrypted = crypt(padded_data, k)
    conn.sendall(b"Your encrypted credentials are: \n" + encrypted.encode('utf-8')+b"\n\n\n")
    return




HOST = "0.0.0.0" 
PORT = 1338

# Création du socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(10)  

print(f"Serveur en attente de connexions sur {HOST}:{PORT}...")

# Fonction pour gérer chaque client
def handle_client(conn, addr):
    print(f"Connexion reçue de {addr}")
    
    k=key.key()
    while True:
        try:
            conn.sendall(b"""Welcome! Would you like to come to the block party? If yes, please register.
                   Type the number corresponding to your choice and press enter.
                   1: register
                   2: login
                   3: exit
               """)
            
            
            # Répondre au client
            data = conn.recv(1024)
            if(data == b"1\n"):
                register(k)
            if(data == b"2\n"):
                login(k)
            if(data == b"3\n"):
                conn.sendall(b"Goodbye! LOOSER!")
                break
            
            
            
           
            if not data:
                break
        except ConnectionResetError:
            break
    print(f"Connexion fermée avec {addr}")
    conn.close()

# Accepter plusieurs connexions
while True:
    conn, addr = server_socket.accept()
    client_thread = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
    client_thread.start()

