# HTTPixel

Vous êtes un analyste en sécurité réseau débutant. 
Votre mission, si vous l'acceptez, est d'intercepter un message secret dissimulé dans un simple échange HTTP. 
Un agent a intercepté un trafic réseau suspect. Votre tâche consiste à extraire ces informations  de la capture réseau et à reconstituer le message.

