# CTF Challenge : Déchiffrement de trafic HTTPS


## Setup

sudo docker build -t certifishark .
sudo docker run -p 10443:10443 --name certifishark -d certifishark 

## Description

Un client vous a mandaté pour une mission délicate : déchiffrer une capture réseau chiffrée provenant du serveur ctf.bdepalme.fr. Votre objectif ? Exposer le contenu caché de ce trafic web et résoudre le mystère qu'il renferme.

## Étapes à suivre

1.  **Analyse du trafic Wireshark**
    *   Vous disposez d'une capture Wireshark contenant du trafic HTTPS chiffré. Pour l'instant, vous ne pouvez pas lire le contenu.
    *   Un lien vers un site web est fourni : `ctf.bdepalme.fr`. Il s'agit d'un site en construction.
    *   En analysant la capture wireshark, on peut découvrir que le port utilisé par le serveur est `10443`

2.  **Recherche d'informations sensibles**
    *   Le site web est en construction, ce qui peut indiquer la présence de fichiers ou de dossiers oubliés.
    *   Effectuez une énumération du site pour découvrir des ressources cachées.
    *   Indice : un dossier `.git` pourrait être présent.

3.  **Extraction du dépôt Git**
    *   Si un dossier `.git` est découvert, utilisez un outil comme `git-dumper` pour extraire l'intégralité du dépôt.

4.  **Récupération de la clé privée**
    *   Parcourez les fichiers extraits du dépôt Git.
    *   Recherchez un dossier `ssl` contenant les clés du serveur (`cert.pem` et `key.pem`).
    *   La clé privée (`key.pem`) est essentielle pour la suite.

5.  **Configuration de Wireshark**
    *   Ouvrez Wireshark et accédez aux préférences.
    *   Allez dans `SSL/TLS` -> `RSA Key List`.
    *   Ajoutez une nouvelle entrée avec les paramètres suivants :
        *   `IP address`: `127.0.0.1`
        *   `Port`: `10443`
        *   `Protocol`: `HTTP`
        *   `Key file`: Indiquez le chemin vers le fichier `key.pem` extrait du dépôt Git.

6.  **Déchiffrement et analyse du trafic**
    *   Wireshark devrait maintenant déchiffrer le trafic HTTPS.
    *   Recherchez une requête vers `/flag.html`.
    *   La réponse à cette requête contiendra le flag.

## Indices (Hints)

*   **Hint 0**: Le port du serveur est 10443 ( ctf.bdepalme.fr:10443 )
*   **Hint 1**: Il est nécessaire de disposer de la clée privée du serveur pour déchiffrer le traffic
*   **Hint 2**: Le site est en construction, peut-être qu'ils ont oublié des fichiers/dossiers utiles.
*   **Hint 3**: `/.git/`
*   **Hint 4**: Il existe des outils pour retrouver les sources à l'aide du dossier `.git`.
*   **Hint 5**: Wireshark à des options pour utiliser la clée privée et déchiffrer le contenu.

## Flag

`CTFAC{ne_pas_laisser_de_.git_en_ligne}`
